//
//  LetsEatSwiftUIApp.swift
//  LetsEatSwiftUI
//
//  Created by iOS16Programming on 04/09/2022.
//

import SwiftUI

@main
struct LetsEatSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
