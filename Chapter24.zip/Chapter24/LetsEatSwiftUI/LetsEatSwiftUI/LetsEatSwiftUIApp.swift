//
//  LetsEatSwiftUIApp.swift
//  LetsEatSwiftUI
//
//  Created by iOS 16 Programming for Beginners on 09/07/2022.
//

import SwiftUI

@main
struct LetsEatSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
