//
//  FilterDataManager.swift
//  LetsEat
//
//  Created by iOS 16 Programming for Beginners on 29/06/2022.
//

import Foundation

class FilterDataManager: DataManager {
    func fetch() -> [FilterItem] {
        var filterItems: [FilterItem] = []
        for data in loadPlist(file: "FilterData") {
            filterItems.append(FilterItem(dict: data as! [String:String]))
        }
        return filterItems
    }
}
