//
//  Device.swift
//  LetsEat
//
//  Created by iOS 16 Programming for Beginners on 03/07/2022.
//

import UIKit
enum Device {
    static var isPhone: Bool {
        UIDevice.current.userInterfaceIdiom == .phone
    }
    static var isPad: Bool {
        UIDevice.current.userInterfaceIdiom == .pad
    }
}
