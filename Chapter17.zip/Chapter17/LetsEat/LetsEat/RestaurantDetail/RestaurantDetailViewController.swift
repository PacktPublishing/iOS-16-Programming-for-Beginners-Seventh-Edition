//
//  RestaurantDetailViewController.swift
//  LetsEat
//
//  Created by iOS 16 Programming for Beginners on 23/06/2022.
//

import UIKit

class RestaurantDetailViewController: UITableViewController {
    
    var selectedRestaurant: RestaurantItem?

    override func viewDidLoad() {
        super.viewDidLoad()
        dump(selectedRestaurant as Any)
    }
}
