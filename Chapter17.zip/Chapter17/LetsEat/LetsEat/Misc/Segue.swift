//
//  Segue.swift
//  LetsEat
//
//  Created by iOS16Programming on 15/08/2022.
//

import Foundation

enum Segue: String {
    case showDetail
    case showRating
    case showReview
    case showAllReviews
    case restaurantList
    case locationList
    case showPhotoReview
    case showPhotoFilter
}
