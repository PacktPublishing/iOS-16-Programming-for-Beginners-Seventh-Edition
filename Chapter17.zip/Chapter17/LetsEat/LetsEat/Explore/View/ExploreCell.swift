//
//  ExploreCell.swift
//  LetsEat
//
//  Created by iOS16Programming on 11/08/2022.
//

import UIKit

class ExploreCell: UICollectionViewCell {
    
    @IBOutlet var exploreNameLabel: UILabel!
    
    @IBOutlet var exploreImageView: UIImageView!
    
}
