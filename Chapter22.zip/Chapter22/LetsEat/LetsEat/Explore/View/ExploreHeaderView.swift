//
//  ExploreHeaderView.swift
//  LetsEat
//
//  Created by iOS 16 Programming for Beginners on 25/06/2022.
//

import UIKit

class ExploreHeaderView: UICollectionReusableView {
        
    @IBOutlet var locationLabel: UILabel!
}
