//
//  ExploreHeaderView.swift
//  LetsEat
//
//  Created by iOS16Programming on 27/09/2022.
//

import UIKit

class ExploreHeaderView: UICollectionReusableView {
    
    @IBOutlet var locationLabel: UILabel!
    
}
