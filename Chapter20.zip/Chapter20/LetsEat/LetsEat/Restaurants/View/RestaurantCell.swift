//
//  RestaurantCell.swift
//  LetsEat
//
//  Created by iOS16Programming on 15/08/2022.
//

import UIKit

class RestaurantCell: UICollectionViewCell {
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var cuisineLabel: UILabel!
    @IBOutlet var restaurantImageView: UIImageView!
    
}
